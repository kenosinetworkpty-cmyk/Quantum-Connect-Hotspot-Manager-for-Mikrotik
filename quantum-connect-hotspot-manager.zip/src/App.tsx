/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Success from './pages/Success';
import ActiveSession from './pages/ActiveSession';
import Warning from './pages/Warning';
import Expired from './pages/Expired';
import Callback from './pages/Callback';
import Admin from './pages/Admin';

export default function App() {
  return (
    <Router>
      <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-blue-500 selection:text-white">
        <Routes>
          <Route path="/" element={<Navigate to="/login" replace />} />
          <Route path="/login" element={<Login />} />
          <Route path="/success" element={<Success />} />
          <Route path="/active" element={<ActiveSession />} />
          <Route path="/warning" element={<Warning />} />
          <Route path="/expired" element={<Expired />} />
          <Route path="/callback" element={<Callback />} />
          <Route path="/admin" element={<Admin />} />
        </Routes>
      </div>
    </Router>
  );
}
