import { useNavigate } from 'react-router-dom';
import { AlertTriangle, PhoneCall, Wifi } from 'lucide-react';

export default function Warning() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 sm:p-8">
      <div className="w-full max-w-md bg-white p-8 rounded-3xl shadow-xl border border-yellow-200 text-center space-y-6 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-yellow-400"></div>
        
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-yellow-100 mb-2">
          <AlertTriangle className="w-10 h-10 text-yellow-600 animate-bounce" />
        </div>
        
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-slate-900">Session Ending! ⏳</h1>
          <p className="text-slate-500 font-medium text-lg">Your free Wi-Fi will disconnect in 5 minutes.</p>
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-6 space-y-4">
          <h2 className="text-lg font-bold text-yellow-900">
            Don't lose your connection!
          </h2>
          <p className="text-sm text-yellow-800 font-medium">
            Get unlimited home internet today. No more daily limits or data costs.
          </p>
          
          <div className="space-y-3 pt-2">
            <button
              onClick={() => navigate('/callback')}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 rounded-xl shadow-lg shadow-blue-600/20 transition-all active:scale-[0.98] flex items-center justify-center gap-2"
            >
              <PhoneCall className="w-5 h-5" />
              Request Callback
            </button>
            <button
              onClick={() => navigate('/active')}
              className="w-full bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 font-bold py-3.5 rounded-xl transition-all active:scale-[0.98] flex items-center justify-center gap-2"
            >
              <Wifi className="w-5 h-5" />
              Continue Browsing
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
