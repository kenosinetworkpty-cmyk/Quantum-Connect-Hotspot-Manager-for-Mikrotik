import { useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Wifi, Zap } from 'lucide-react';
import OTPForm from '../components/OTPForm';
// import { db } from '../firebase';
// import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

export default function Login() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const location = searchParams.get('location') || 'Local Spaza';

  const handleLoginSuccess = async (data: { name: string; phone: string; wantsCallback: boolean }) => {
    try {
      // MOCK FIRESTORE SAVE
      // await addDoc(collection(db, 'leads'), {
      //   name: data.name,
      //   phone: data.phone,
      //   location,
      //   wantsCallback: data.wantsCallback,
      //   createdAt: serverTimestamp()
      // });
      
      // Save session info
      localStorage.setItem('qc_user', JSON.stringify({ name: data.name, phone: data.phone, location }));
      
      // Redirect to success page before granting internet
      navigate('/success');
    } catch (error) {
      console.error('Failed to save lead:', error);
      // Still let them through if DB fails, don't block Wi-Fi
      navigate('/success');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 sm:p-8">
      <div className="w-full max-w-md mb-8 text-center space-y-2">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-600 shadow-xl shadow-blue-600/20 mb-4">
          <Wifi className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight">
          Welcome to <span className="text-blue-600">{location}</span>
        </h1>
        <p className="text-slate-500 font-medium text-lg">
          Get 30 Minutes Free Internet 🎉
        </p>
      </div>

      <OTPForm onSuccess={handleLoginSuccess} />

      <div className="mt-12 text-center space-y-4">
        <div className="flex items-center justify-center gap-2 text-slate-400 font-medium text-sm uppercase tracking-widest">
          <Zap className="w-4 h-4 text-blue-500" />
          Powered by Quantum Connect
        </div>
      </div>
    </div>
  );
}
