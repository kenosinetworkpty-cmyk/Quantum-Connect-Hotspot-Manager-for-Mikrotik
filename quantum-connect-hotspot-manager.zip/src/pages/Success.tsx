import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle2, PhoneCall, Wifi } from 'lucide-react';

export default function Success() {
  const navigate = useNavigate();

  useEffect(() => {
    // Start the session timer
    const sessionEnd = Date.now() + 30 * 60 * 1000; // 30 mins
    localStorage.setItem('qc_sessionEnd', sessionEnd.toString());
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 sm:p-8">
      <div className="w-full max-w-md bg-white p-8 rounded-3xl shadow-xl border border-slate-100 text-center space-y-6">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-green-100 mb-2">
          <CheckCircle2 className="w-10 h-10 text-green-600" />
        </div>
        
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-slate-900">You're connected! 🚀</h1>
          <p className="text-slate-500 font-medium">Enjoy your 30 minutes of free Wi-Fi.</p>
        </div>

        <div className="bg-blue-50 border border-blue-100 rounded-2xl p-6 space-y-4">
          <h2 className="text-lg font-semibold text-blue-900">
            Want this internet at home every day?
          </h2>
          <p className="text-sm text-blue-700">
            Get unlimited, fast home fibre for your whole family. No more data costs!
          </p>
          
          <div className="space-y-3 pt-2">
            <button
              onClick={() => navigate('/callback')}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3.5 rounded-xl shadow-lg shadow-blue-600/20 transition-all active:scale-[0.98] flex items-center justify-center gap-2"
            >
              <PhoneCall className="w-5 h-5" />
              Request a Callback
            </button>
            <button
              onClick={() => navigate('/active')}
              className="w-full bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 font-semibold py-3.5 rounded-xl transition-all active:scale-[0.98] flex items-center justify-center gap-2"
            >
              <Wifi className="w-5 h-5" />
              Continue to Internet
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
