import { useState, useEffect } from 'react';
import { BarChart3, Users, PhoneCall, MapPin, Search } from 'lucide-react';
// import { db } from '../firebase';
// import { collection, getDocs, query, orderBy } from 'firebase/firestore';

export default function Admin() {
  const [leads, setLeads] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // MOCK DATA FETCHING
    const fetchLeads = async () => {
      try {
        // const q = query(collection(db, 'leads'), orderBy('createdAt', 'desc'));
        // const querySnapshot = await getDocs(q);
        // const leadsData = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        
        // Mock data
        const mockLeads = [
          { id: '1', name: 'Sipho', phone: '082 123 4567', location: 'Sipho Spaza - Zone A', wantsCallback: true, createdAt: new Date().toISOString() },
          { id: '2', name: 'Thabo', phone: '071 987 6543', location: 'Mama Joy Tuckshop', wantsCallback: false, createdAt: new Date(Date.now() - 86400000).toISOString() },
          { id: '3', name: 'Lerato', phone: '063 456 7890', location: 'Sipho Spaza - Zone A', wantsCallback: true, createdAt: new Date(Date.now() - 172800000).toISOString() },
        ];
        
        setTimeout(() => {
          setLeads(mockLeads);
          setLoading(false);
        }, 1000);
      } catch (error) {
        console.error('Error fetching leads:', error);
        setLoading(false);
      }
    };

    fetchLeads();
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 p-4 sm:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Quantum Connect Admin</h1>
            <p className="text-slate-500 font-medium">Sales Dashboard & Lead Engine</p>
          </div>
          <div className="flex items-center gap-3 bg-white px-4 py-2 rounded-xl shadow-sm border border-slate-200">
            <Search className="w-5 h-5 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search leads..." 
              className="outline-none bg-transparent text-sm font-medium text-slate-700 w-full sm:w-64"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-500 uppercase tracking-wider">Total Logins</p>
              <p className="text-2xl font-bold text-slate-900">1,248</p>
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center">
              <PhoneCall className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-500 uppercase tracking-wider">Callback Requests</p>
              <p className="text-2xl font-bold text-slate-900">342</p>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center">
              <BarChart3 className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-500 uppercase tracking-wider">Conversion Rate</p>
              <p className="text-2xl font-bold text-slate-900">27.4%</p>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-orange-100 flex items-center justify-center">
              <MapPin className="w-6 h-6 text-orange-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-500 uppercase tracking-wider">Active Outlets</p>
              <p className="text-2xl font-bold text-slate-900">14</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex items-center justify-between">
            <h2 className="text-xl font-bold text-slate-900">Recent Leads</h2>
            <button className="text-sm font-bold text-blue-600 hover:text-blue-700">Export CSV</button>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-500 text-sm uppercase tracking-wider">
                  <th className="p-4 font-semibold">Name</th>
                  <th className="p-4 font-semibold">Phone</th>
                  <th className="p-4 font-semibold">Location</th>
                  <th className="p-4 font-semibold">Status</th>
                  <th className="p-4 font-semibold">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {loading ? (
                  <tr>
                    <td colSpan={5} className="p-8 text-center text-slate-500 font-medium">Loading leads...</td>
                  </tr>
                ) : leads.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-8 text-center text-slate-500 font-medium">No leads found.</td>
                  </tr>
                ) : (
                  leads.map((lead) => (
                    <tr key={lead.id} className="hover:bg-slate-50 transition-colors">
                      <td className="p-4 font-medium text-slate-900">{lead.name}</td>
                      <td className="p-4 text-slate-600 font-mono">{lead.phone}</td>
                      <td className="p-4 text-slate-600">{lead.location}</td>
                      <td className="p-4">
                        {lead.wantsCallback ? (
                          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-green-100 text-green-800">
                            Hot Lead
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-600">
                            Wi-Fi Only
                          </span>
                        )}
                      </td>
                      <td className="p-4 text-slate-500 text-sm">
                        {new Date(lead.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
