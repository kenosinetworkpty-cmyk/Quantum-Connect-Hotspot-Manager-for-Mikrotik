import { useNavigate } from 'react-router-dom';
import { PhoneCall, ShoppingCart, WifiOff, Zap } from 'lucide-react';

export default function Expired() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 sm:p-8">
      <div className="w-full max-w-md bg-white p-8 rounded-3xl shadow-xl border border-red-100 text-center space-y-8 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-red-500"></div>
        
        <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-red-50 mb-2">
          <WifiOff className="w-12 h-12 text-red-500" />
        </div>
        
        <div className="space-y-3">
          <h1 className="text-3xl font-bold text-slate-900">Session Expired</h1>
          <p className="text-slate-500 font-medium text-lg">Your 30 minutes of free Wi-Fi has ended.</p>
        </div>

        <div className="bg-blue-600 text-white rounded-2xl p-6 text-left space-y-4 relative overflow-hidden shadow-2xl shadow-blue-600/30">
          <div className="absolute -right-4 -top-4 w-24 h-24 bg-white/10 rounded-full blur-2xl"></div>
          <div className="absolute -left-4 -bottom-4 w-32 h-32 bg-blue-400/20 rounded-full blur-3xl"></div>
          
          <div className="relative z-10 space-y-4">
            <div className="flex items-center gap-2">
              <Zap className="w-6 h-6 text-yellow-300" />
              <h2 className="text-xl font-bold">Get Uncapped Wi-Fi</h2>
            </div>
            <p className="text-blue-100 font-medium leading-relaxed">
              Stop worrying about data limits. Get fast, uncapped internet installed at your home from R299/month!
            </p>
            <button
              onClick={() => navigate('/callback')}
              className="w-full bg-white hover:bg-blue-50 text-blue-700 font-bold py-4 rounded-xl shadow-lg transition-all active:scale-[0.98] flex items-center justify-center gap-2 mt-4 text-lg"
            >
              <PhoneCall className="w-6 h-6" />
              Call Me Back
            </button>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100">
          <button
            disabled
            className="w-full bg-slate-100 text-slate-400 font-bold py-4 rounded-xl border border-slate-200 flex items-center justify-center gap-2 cursor-not-allowed"
          >
            <ShoppingCart className="w-5 h-5" />
            Buy Data (Coming Soon)
          </button>
        </div>
      </div>
    </div>
  );
}
