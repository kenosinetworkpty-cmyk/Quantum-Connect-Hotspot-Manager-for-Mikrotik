import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Clock, PhoneCall, ShieldCheck, Zap } from 'lucide-react';

export default function ActiveSession() {
  const navigate = useNavigate();
  const [timeLeft, setTimeLeft] = useState<number>(30 * 60); // 30 mins in seconds

  useEffect(() => {
    const sessionEndStr = localStorage.getItem('qc_sessionEnd');
    if (!sessionEndStr) {
      navigate('/login');
      return;
    }

    const sessionEnd = parseInt(sessionEndStr, 10);

    const interval = setInterval(() => {
      const remaining = Math.floor((sessionEnd - Date.now()) / 1000);
      
      if (remaining <= 0) {
        clearInterval(interval);
        navigate('/expired');
      } else if (remaining <= 5 * 60 && remaining > (5 * 60 - 1)) {
        // Just crossed the 5 minute mark
        navigate('/warning');
      } else {
        setTimeLeft(remaining);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [navigate]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 sm:p-8">
      <div className="w-full max-w-md bg-white p-8 rounded-3xl shadow-xl border border-slate-100 text-center space-y-8">
        <div className="space-y-4">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-blue-100 mb-2">
            <Clock className="w-10 h-10 text-blue-600 animate-pulse" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900">Active Session</h1>
          <p className="text-slate-500 font-medium">You are connected to free Wi-Fi.</p>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 space-y-2">
          <p className="text-sm font-medium text-slate-500 uppercase tracking-widest">Time Remaining</p>
          <p className="text-5xl font-mono font-bold text-slate-900 tracking-tight">
            {formatTime(timeLeft)}
          </p>
        </div>

        <div className="bg-blue-600 text-white rounded-2xl p-6 text-left space-y-4 relative overflow-hidden">
          <div className="absolute -right-4 -top-4 w-24 h-24 bg-white/10 rounded-full blur-2xl"></div>
          <div className="absolute -left-4 -bottom-4 w-32 h-32 bg-blue-400/20 rounded-full blur-3xl"></div>
          
          <div className="relative z-10 space-y-4">
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-yellow-300" />
              <h2 className="text-lg font-bold">Upgrade to Home Fibre</h2>
            </div>
            <p className="text-blue-100 text-sm font-medium leading-relaxed">
              Stop worrying about data limits. Get fast, uncapped internet installed at your home for free!
            </p>
            <ul className="space-y-2 text-sm font-medium text-blue-50">
              <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-green-400" /> Free Installation</li>
              <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-green-400" /> No Contracts</li>
            </ul>
            <button
              onClick={() => navigate('/callback')}
              className="w-full bg-white hover:bg-blue-50 text-blue-700 font-bold py-3 rounded-xl shadow-lg transition-all active:scale-[0.98] flex items-center justify-center gap-2 mt-2"
            >
              <PhoneCall className="w-5 h-5" />
              Call Me Back
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
