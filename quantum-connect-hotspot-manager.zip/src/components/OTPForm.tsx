import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Loader2, Phone, User } from 'lucide-react';
import { cn } from '../lib/utils';
// import { setupRecaptcha, auth } from '../firebase';
// import { signInWithPhoneNumber } from 'firebase/auth';

interface OTPFormProps {
  onSuccess: (data: { name: string; phone: string; wantsCallback: boolean }) => void;
}

export default function OTPForm({ onSuccess }: OTPFormProps) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const [consent, setConsent] = useState(false);
  const [wantsCallback, setWantsCallback] = useState(true); // Pre-ticked for conversion

  const handleSendOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!consent) {
      setError('You must agree to the Terms & Conditions to continue.');
      return;
    }
    if (phone.length < 9) {
      setError('Please enter a valid mobile number.');
      return;
    }
    
    setError('');
    setLoading(true);
    
    try {
      // MOCK OTP SENDING for preview environment
      // In production:
      // const appVerifier = setupRecaptcha('recaptcha-container');
      // const confirmationResult = await signInWithPhoneNumber(auth, phone, appVerifier);
      // window.confirmationResult = confirmationResult;
      
      setTimeout(() => {
        setStep('otp');
        setLoading(false);
      }, 1000);
    } catch (err: any) {
      setError(err.message || 'Failed to send OTP');
      setLoading(false);
    }
  };

  const handleVerifyOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length < 4) {
      setError('Please enter a valid OTP.');
      return;
    }

    setError('');
    setLoading(true);

    try {
      // MOCK OTP VERIFICATION
      // In production:
      // await window.confirmationResult.confirm(otp);
      
      setTimeout(() => {
        setLoading(false);
        onSuccess({ name, phone, wantsCallback });
      }, 1000);
    } catch (err: any) {
      setError('Invalid OTP. Please try again.');
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto bg-white p-6 rounded-2xl shadow-xl border border-slate-100">
      <div id="recaptcha-container"></div>
      
      {step === 'phone' ? (
        <form onSubmit={handleSendOTP} className="space-y-4">
          <div className="space-y-1">
            <label className="text-sm font-medium text-slate-700">First Name</label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all outline-none bg-slate-50"
                placeholder="e.g. Sipho"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-sm font-medium text-slate-700">Mobile Number</label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all outline-none bg-slate-50"
                placeholder="082 123 4567"
              />
            </div>
          </div>

          <div className="space-y-3 pt-2">
            <label className="flex items-start gap-3 cursor-pointer group">
              <div className="relative flex items-center justify-center mt-0.5">
                <input
                  type="checkbox"
                  checked={consent}
                  onChange={(e) => setConsent(e.target.checked)}
                  className="peer w-5 h-5 border-2 border-slate-300 rounded text-blue-600 focus:ring-blue-500 transition-colors"
                />
              </div>
              <span className="text-sm text-slate-600 leading-tight">
                I agree to the <a href="#" className="text-blue-600 hover:underline">Terms & Conditions</a> and consent to being contacted (POPIA).
              </span>
            </label>

            <label className="flex items-start gap-3 cursor-pointer group bg-blue-50 p-3 rounded-xl border border-blue-100">
              <div className="relative flex items-center justify-center mt-0.5">
                <input
                  type="checkbox"
                  checked={wantsCallback}
                  onChange={(e) => setWantsCallback(e.target.checked)}
                  className="peer w-5 h-5 border-2 border-blue-300 rounded text-blue-600 focus:ring-blue-500 transition-colors bg-white"
                />
              </div>
              <span className="text-sm font-medium text-blue-900 leading-tight">
                Yes, I want unlimited home fibre. Please call me back! 🚀
              </span>
            </label>
          </div>

          {error && <p className="text-red-500 text-sm font-medium">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3.5 rounded-xl shadow-lg shadow-blue-600/20 transition-all active:scale-[0.98] disabled:opacity-70 disabled:pointer-events-none flex items-center justify-center"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Get 30 Mins Free Wi-Fi'}
          </button>
        </form>
      ) : (
        <form onSubmit={handleVerifyOTP} className="space-y-4">
          <div className="text-center mb-6">
            <h3 className="text-lg font-semibold text-slate-900">Enter Verification Code</h3>
            <p className="text-sm text-slate-500 mt-1">We sent a code to {phone}</p>
          </div>

          <div className="space-y-1">
            <input
              type="text"
              required
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              className="w-full px-4 py-3 text-center text-2xl tracking-[0.5em] rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all outline-none bg-slate-50 font-mono"
              placeholder="••••"
              maxLength={6}
            />
          </div>

          {error && <p className="text-red-500 text-sm font-medium text-center">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3.5 rounded-xl shadow-lg shadow-blue-600/20 transition-all active:scale-[0.98] disabled:opacity-70 disabled:pointer-events-none flex items-center justify-center"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Verify & Connect'}
          </button>
          
          <button
            type="button"
            onClick={() => setStep('phone')}
            className="w-full text-slate-500 text-sm font-medium hover:text-slate-800 py-2"
          >
            Change Phone Number
          </button>
        </form>
      )}
    </div>
  );
}
